**2020 Update**
I am restarting the project so watch this space


Blue Rhinos Consulting
Andrew Milsted | andrew@bluerhinos.co.uk | http://www.bluerhinos.co.uk | @bluerhinos

A simple php class to connect/publish/subscribe to an MQTT broker

Documentation: Coming Soon
Source: http://github.com/bluerhinos/phpMQTT

To install via Composer
-----------------------
`composer require bluerhinos/phpmqtt=@dev`
